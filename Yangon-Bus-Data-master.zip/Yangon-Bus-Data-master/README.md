# Yangon-Bus-Data
A CSV Data For the new yangon bus

**buslines.csv** are in the format of 

*bus_id , destination*

### Disclaimer
I'm not affiliated with Yangon Bus Service. Data are pulled from [Yangon Bus website](http://yangonbus.com/) using a html parser. I **DO NOT** guarantee the CSV will be updated as soon as data is changed in Yangon Bus Website.

**Please Fork and Contribute the data sheet**

###TODO
>* Add Locations.csv
